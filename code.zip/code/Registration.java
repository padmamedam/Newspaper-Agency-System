/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    import javax.swing.*;  
    import java.awt.*;  
    import java.awt.event.*;  
import java.io.IOException;
    import java.sql.*;  
import java.text.ParseException;
import java.text.SimpleDateFormat;
    //import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
    
import java.text.ParseException;  
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.Locale;   
    public class Registration extends JFrame implements ActionListener   
    {  
         SimpleDateFormat format;
        JLabel l, l1, l2, l3, l4, l5, l7, l8,l9,l6,name,emai,pd,cpd,ad,st,pno,pd1; 
        //JTextArea l6;
        JTextField tf,tf1, tf2, tf7;
        JComboBox tf6,tf8;
        JTextArea tf5;
        JButton btn1, btn2,back;  
        JPasswordField p1, p2;
        String s;
        Date d3;
        int diff;
         java.sql.Date date;
        String states[] = new String[50];
        String papers[] =new String[10];
        Registration() throws ClassNotFoundException
        {  
            setVisible(true);  
            setSize(1000, 1000);  
            setLayout(null);
            //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setTitle("Registration Form in Java"); 
            Random rnd = new Random();
            int n=100000+rnd.nextInt(900000);
            l= new JLabel("CustomerId:");  
            l1 = new JLabel("Registration Form :");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            l2 = new JLabel("Name:");  
            l3 = new JLabel("Email-ID:");  
            l4 = new JLabel("Create Password:");  
            l5 = new JLabel("Confirm Password:");  
            l6 = new JLabel("address:");  
            l7 = new JLabel("state:");  
            l8 = new JLabel("Phone No:"); 
            l9 = new JLabel("Newspaper Name:"); 
            tf1=new JTextField();
            tf=new JTextField();
            tf.setText(Integer.toString(n));
            tf.setEnabled(false);
            tf2 = new JTextField();  
            p1 = new JPasswordField();  
            p2 = new JPasswordField();  
            tf5 = new JTextArea();  
             tf6 = new JComboBox();    
            tf7 = new JTextField(); 
            tf8 = new JComboBox();  
            btn1 = new JButton("Submit");  
            btn2 = new JButton("Clear");
            back=new JButton("Back");
            btn1.addActionListener(this);  
            btn2.addActionListener(this); 
            back.addActionListener(this);
            l.setBounds(80, 30, 400, 30); 
            l1.setBounds(100, 10, 400, 30);  
            l2.setBounds(80, 70, 200, 30);  
            l3.setBounds(80, 110, 200, 30);  
            l4.setBounds(80, 150, 200, 30);  
            l5.setBounds(80, 190, 200, 30);  
            l6.setBounds(80, 230, 200, 30);  
            l7.setBounds(80, 350, 200, 30);  
            l8.setBounds(80, 390, 200, 30);
            l9.setBounds(80, 430, 200, 30);
            tf.setBounds(300, 30, 200, 30);  
            tf1.setBounds(300, 70, 200, 30);  
            tf2.setBounds(300, 110, 200, 30);  
            p1.setBounds(300, 150, 200, 30);  
            p2.setBounds(300, 190, 200, 30);  
            tf5.setBounds(300, 230, 200, 80);  
            tf6.setBounds(300, 350, 200, 30);  
            tf7.setBounds(300, 390, 200, 30);
            tf8.setBounds(300, 430, 200, 30);  
            name=new JLabel("");
            name.setForeground(Color.red);
            emai=new JLabel("");
            emai.setForeground(Color.red);
            pd=new JLabel("");
            pd.setForeground(Color.red);
             pd1=new JLabel("");
             pd1.setForeground(Color.red);
            cpd=new JLabel("");
            cpd.setForeground(Color.red);
            ad=new JLabel("");
            ad.setForeground(Color.red);
            st=new JLabel("");
            st.setForeground(Color.red);
            pno=new JLabel("");
            pno.setForeground(Color.red);
            name.setBounds(510,70,300,20);
            emai.setBounds(510,110,350,20);
            pd.setBounds(510,150,350,10);
            pd1.setBounds(510,170,350,20);
            cpd.setBounds(510,190,350,20);
            ad.setBounds(510,250,350,20);
            st.setBounds(510,350,350,20);
            pno.setBounds(510,390,350,20);
            btn1.setBounds(50, 470, 100, 30);  
            btn2.setBounds(170, 470, 100, 30);
            back.setBounds(0,0,80,30);
            add(l);
            add(l1);  
            add(l2); 
            add(tf);
            add(tf1);  
            add(l3);  
            add(tf2);  
            add(l4);  
            add(p1);  
            add(l5);  
            add(p2);  
            add(l6);  
            add(tf5);  
            add(l7);  
            add(tf6);  
            add(l8); 
            add(l9);
            add(tf7);
            add(tf8);
            add(btn1);  
            add(btn2);  
            add(back);
             add(back);
            add(name);
            add(emai);
            add(ad);
            add(st);
            add(pno);
            add(pd);
            add(pd1);
            add(cpd);
            for(int i=0;i<10;i++)
            {
                papers[i]="";
            }
         
states[1]="Andhra pradesh";         
states[2] = "Arunachal Pradesh";
states[3] = "Assam";
states[4] = "Bihar";
states[5] = "Chhattisgarh";
states[6] = "Goa";
states[7] = "Gujarat";
states[8] = "Haryana";
states[9] = "Himachal Pradesh";
states[10] = "Jammu and Kashmir";
states[11] = "Jharkhand";
states[12] = "Karnataka";
states[13] = "Kerala";
states[14] = "Madya Pradesh";
states[15] = "Maharashtra";
states[16] = "Manipur";
states[17] = "Meghalaya";
states[18] = "Mizoram";
states[19] = "Nagaland";
states[20] = "Orissa";
states[21] = "Punjab";
states[22] = "Rajasthan";
states[23] = "Sikkim";
states[24] = "Tamil Nadu";
states[25]="Telangana";
states[26] = "Tripura";
states[27] = "Uttaranchal";
states[28] = "Uttar Pradesh";
states[29] = "West Bengal";
states[30] = "Andaman and Nicobar Islands";
states[31] = "Chandigarh";
states[32] = "Dadar and Nagar Haveli";
states[33] = "Daman and Diu";
states[34] = "Delhi";
states[35] = "Lakshadeep";
states[36] = "Pondicherry";
 for (int j= 1; j< 37; j++) { tf6.addItem(states[j]); 
        }  
               for(int i=1;i<10;i++)
                {
                    papers[i]="";
                }
                try
                 {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                    Statement st1=con1.createStatement();      
                    ResultSet rs1=st1.executeQuery("select * from newspaper");       
                    int t=1;
                   
                    while(rs1.next())
                    {              
                        String s=rs1.getString("papername");
                        String c=rs1.getString("cost");
                        //c=" (Rs."+c+")";
                        papers[t]=s;
                        tf8.addItem(papers[t]);
                        t++;
                            
                     }

                } 
                 catch (SQLException ex)
                 { 
                    Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
       
    
            }
    
        
      public void actionPerformed(ActionEvent e)   
        {  
          
            if (e.getSource() == btn1)  
             {  
               if(reg()){
                 int x = 0; 
                String s = tf.getText();  
                String s1 = tf1.getText();  
                String s2 = tf2.getText();  
                char[] s3 = p1.getPassword();  
                char[] s4 = p2.getPassword();   
                String s8 = new String(s3);  
                String s9 = new String(s4);  
                String s5 = tf5.getText();  
                 Object selectedStateobj = tf6.getSelectedItem();
                String selectedState = String.valueOf(selectedStateobj);
                String s6= selectedState;
                String s7 = tf7.getText(); 
                 Object selectedStateobj1 = tf8.getSelectedItem();
                String selectedState1 = String.valueOf(selectedStateobj1);
                String s10= selectedState1;
               
                String s11="UNPAID";
               
                
               
                 Date date3 = new Date();  
                 SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
                String strDate1 = formatter.format(date3);  
                //System.out.println("Date Format with MM/dd/yyyy : "+strDate1);   
                
                
                String s12=String.valueOf(strDate1);
                if (s8.equals(s9))  
                {                    
                    try{  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        System.out.println("Success");
                        PreparedStatement ps = con.prepareStatement("insert into reg(cid,name,emailid,pwd,cpwd,address,state,phoneno,newspaper,Status,date) values(?,?,?,?,?,?,?,?,?,?,?)"); 
                        ps.setString(1, s);  
                        ps.setString(2, s1);  
                        ps.setString(3, s2);
                        ps.setString(4, s8); 
                        ps.setString(5, s9);  
                        ps.setString(6, s5);  
                        ps.setString(7, s6);  
                        ps.setString(8, s7); 
                        ps.setString(9, s10); 
                        ps.setString(10,s11);
                        ps.setString(11,s12);
                        int rs = ps.executeUpdate();      
                        x++;  
                        if (x > 0)   
                        {  
                            JOptionPane.showMessageDialog(btn1, "Data Saved Successfully"); 
                        }
                       
                       
                                                
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }  
                }  
                else  
                {  
                    JOptionPane.showMessageDialog(btn1, "Password Does Not Match");  
                }
              }   
            }
           if(e.getSource() == btn2) 
              {  
                tf1.setText("");  
                tf2.setText("");  
                p1.setText("");  
                p2.setText("");  
                tf5.setText("");  
                tf7.setText("");  
              }
              if(e.getSource() == back)
              {
                              login man2 = null;
                try {
                    man2 = new login();
                } catch (IOException ex) {
                    Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
                }
				setVisible(false);
				man2.setVisible(true);
              }
        }
        public static void main(String args[]) throws ClassNotFoundException  
        {  
            new Registration();  
        }
         public static boolean isvalid(String email){
        String e1="^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; 
                              
        Pattern pat = Pattern.compile(e1); 
        if (email == null) 
            return false; 
        return pat.matcher(email).matches(); 
    
     }
     public static boolean isphn(String s) 
     { 
        
        Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}"); 
  
        Matcher m = p.matcher(s); 
        return (m.find() && m.group().equals(s)); 
     } 
         public static boolean isuname(String s) 
            { 
                      String pattern = "^([a-zA-Z]{2,}\\s[a-zA-z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
                   
            }
     public static boolean ispass(String s) 
     { 
        
        Pattern p=Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
     
   
        Matcher mtch = p.matcher(s);
        if(mtch.matches()){
            return true;
        }
        return false;
      }
       public static boolean ispass1(String s) 
     { 
        
        Pattern p=Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
     
   
        Matcher mtch = p.matcher(s);
        if(mtch.matches()){
            return true;
        }
        return false;
      }
       public static boolean isValidDate(String d) 
       { 
       // String regex = "^(1[0-2]|0[1-9])/(3[01]"
                       //+ "|[12][0-9]|0[1-9])/[0-9]{4}$";
        String regex = "^(\\d{4})-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])$"; 
        Pattern pattern = Pattern.compile(regex); 
        Matcher matcher = pattern.matcher((CharSequence)d); 
        return matcher.matches(); 
        } 
            public boolean reg(){
            String Username = tf1.getText();
            String Passwd = new String(p1.getPassword());
            String Cpasswd = new String(p2.getPassword());
           //String strConfirmPassword = new String(confirmPasswordField.getPassword());
            String address = tf5.getText();
            String strEmail = tf2.getText();
             Object selectedStateobj = tf6.getSelectedItem();
                String selectedState = String.valueOf(selectedStateobj);
                String state = selectedState;  
            String strphone =tf7.getText();
            if(isuname(Username)) 
            {
               name.setText("");
            }
            else
            {
             name.setText("Please Valid Name(ex: Mahadev Sarani)");
            tf1.requestFocusInWindow();
            return false;
            }
            if(isvalid(strEmail))
            {
               emai.setText("");
            }
            else{
                emai.setText("Please valid email(ex:mahadev@gmail.com)");
               tf2.requestFocusInWindow();
           return false;
           }
            if(ispass(Passwd))
            {
                pd.setText("");
                 pd1.setText("");
            }
            else{
             pd.setText("Please enter valid password");
              pd1.setText("Alleast one Capital,one Special& one Integer");
            p1.requestFocusInWindow();
            return false;
            }
            if(ispass1(Cpasswd))
            {
                cpd.setText("");
            }
            else{
             cpd.setText("Please enter password again");
            p1.requestFocusInWindow();
            return false;
            }
             if(address.equals("")) 
            {
            ad.setText("Please Enter Address");
            p2.requestFocusInWindow();
            return false;
            }
            else
            {
                ad.setText("");
            }
             if(state.equals(""))
            {
              st.setText("Please select state");
            tf6.requestFocusInWindow();
            return false;
            }
             else
             {
                 st.setText("");
             }
            if(isphn(strphone)) 
            {
                pno.setText("");
            }else{
            pno.setText("plese enter valid phone number(ex:8932312893)");
            tf7.requestFocusInWindow();
            return false;
            }
            return true;
            
         }

    /**
     *
     * @param args
     */
    
    }  
