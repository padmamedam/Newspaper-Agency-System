import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
class Customer extends  JFrame implements ActionListener   
{
  String uid;
  JButton b;
  public Customer(String uid)
  {
    this.uid=uid;
    setSize(1500,800);
    setLocation(400,300);
    BackgroundPanel bp = new BackgroundPanel();
    JButton button= new JButton("View Myinfo");
    JButton button1= new JButton("Pay Bills");
   
    JButton button3= new JButton("Edit Myinfo");
    //button.setBounds(100,100,180,50);
    //button1.setBounds(300,100,180,50);
    //button2.setBounds(600,700,80,20);
    //button3.setBounds(900,700,80,20);
    b=new JButton("Logout");
    button.setBounds(20,100,200,50);
     button1.setBounds(270,100,250,50);
     
     button3.setBounds(570,100,250,50);
      b.setBounds(870,100,100,50);
     
     add(button);
     add(button1);
     add(b);
     add(button3);
     add(bp);
     
      button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {				
			        Viewinfo man = null;
                            try {
                                man = new Viewinfo(uid);
                            } catch (Exception ex) {
                                Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
                            }
				setVisible(false);
				//man.setVisible(true);
                               
				
			}
		});
      
        button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				paybill man1=new paybill(uid);
				setVisible(false);
				//man1.setVisible(true);
                              
				
			}
		});
      
     
     button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				editinfo man1 = null;
                            try {
                                man1 = new editinfo(uid);
                            } catch (ClassNotFoundException ex) {
                                Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
                            }
				setVisible(false);
				man1.setVisible(true);
                                
				
			}
		});
      b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				homepage man1=new homepage();
				setVisible(false);
				man1.setVisible(true);
                                
				
			}
		});
     
    
  }
 // public static void main(String[] args) {new Customer().setVisible(true);}

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 

 
    
}
class BackgroundPanel1 extends Panel
{
  Image img;
  public BackgroundPanel1()
  {
    try
    {
      img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("ns2.jpg"), "ns2.jpg"));
    }
    catch(Exception e){/*handled in paint()*/}
  }
  public void paint(Graphics g)
  {
    super.paint(g);
    if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
    else g.drawString("No Image",100,100);
  }
}  