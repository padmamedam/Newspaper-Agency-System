//package newspaper;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.Date;

class NewsAgent extends JFrame implements ActionListener   
{
    JButton button,button1,button2,button3,button5,button6;
    String s,s3,s4;
    Date d3=null;
    Date d1=null;
  public NewsAgent()
  {
    setSize(1200,700);
    //setLocation(400,300);
    BackgroundPanel bp = new BackgroundPanel();
  //  setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
     button= new JButton("view customerinfo");
     button1= new JButton("Add NewsPaper");
     button2= new JButton("Edit NewsPaper");
     button3= new JButton("Print Addres");
     button5=new JButton("update");
     button6=new JButton("Logout");
    
     button.setBounds(0,100,200,50);
     button1.setBounds(210,100,200,50);
     button2.setBounds(420,100,200,50);
     button3.setBounds(630,100,200,50);
     button5.setBounds(840,100,200,50);
     button6.setBounds(1050,100,150,50);
   
     add(button);
     add(button1);
     add(button2);
     add(button3);
     add(button5);
     add(button6);
     add(bp);
    
     button.addActionListener(this);
     button1.addActionListener(this);
     button2.addActionListener(this);
     button3.addActionListener(this);
     button5.addActionListener(this);
     button6.addActionListener(this);
    
    
  }
  public static void main(String[] args) {new NewsAgent().setVisible(true);}
   
  public void actionPerformed(ActionEvent e)
  {
      if(e.getSource()==button)
      {
          	
	 Viewinfo1 ln1 = null;
          try {
              ln1 = new Viewinfo1();
               setVisible(false);                
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
               dispose();
				
      }
      if(e.getSource()==button1)
      {
          Addnew ln2 = null;
          try {
              ln2 = new Addnew();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
                ln2.setVisible(true);
                dispose();
      }
      if(e.getSource()==button2)
      {
          Editpaper ln3= null;
          try {
              ln3 = new Editpaper();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
                ln3.setVisible(true);
                dispose();
      }
      if(e.getSource()==button3)
      {
          Printaddress ln4 = null;
          try {
              ln4= new Printaddress();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
               
      }
      
     
        if(e.getSource()==button5)
      {
          Updatecstatus ln4 = null;
          try {
              ln4= new Updatecstatus();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
               
      }
        if(e.getSource()==button6)
      {
          homepage lnp = null;
          try {
              lnp= new homepage();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
                lnp.setVisible(true);
                dispose();
      }
      
      
      
      
      
  }  
     
}
class BackgroundPanel2 extends Panel
{
  Image img;
  public BackgroundPanel2()
  {
    try
    {
      img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("ns2.jpg"), "ns2.jpg"));
    }
    catch(Exception e){/*handled in paint()*/}
  }
  public void paint(Graphics g)
  {
    super.paint(g);
    if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
    else g.drawString("No Image",100,100);
  }
}  