/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.*;
class homepage extends Frame
{
  JLabel h;
  public homepage()
  {
      
    setSize(1200,700);
    setLocation(400,300);
    BackgroundPanel bp = new BackgroundPanel();
    JButton button= new JButton("Manager");
    JButton button1= new JButton("News Agent");
    JButton button2= new JButton("Customer");
    JButton button3= new JButton("newspaper details");
    h=new JLabel("News Paper Agency System");
    h.setFont(new Font("Dialog", Font.BOLD, 25));
        h.setBounds(350,30,400,40);
        h.setForeground(Color.black);
    
    button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				login1 ln;
                            try {
                                ln = new login1();
                                setVisible(false);
				ln.setVisible(true);
                                dispose();
                            } catch (IOException ex) {
                                Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                            }
				
				
			}
		});
    
    
    
       button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				login ln;
                            try {
                                ln = new login();
                                setVisible(false);
				ln.setVisible(true);
                                dispose();
                            } catch (IOException ex) {
                                Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                            }
				
				
			}
		});
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				login2 ln = null;
                            try {
                                ln = new login2();
                            } catch (IOException ex) {
                                Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                            }
                                setVisible(false);
                                ln.setVisible(true);
                                dispose();
				
				
			}
		});
        
        
        button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				newspaperdetails ln = null;
                            try {
                                ln = new newspaperdetails();
                            } catch (IOException ex) {
                                Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (Exception ex) {
                                Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                            }
                                //setVisible(false);
                                //ln.setVisible(true);
                                dispose();
				
				
			}
		});
    
     
    
   //JLabel l1=new JLabel("NEWS PAPER AGENCY SYSTEM");
    //l1.setFont(new Font("Dialog",Font.ITALIC,20));
   // l1.setBounds(350,30,230,40);
    
     button.setBounds(100,120,250,50);
     button1.setBounds(400,120,250,50);
     button2.setBounds(700,120,250,50);
     button3.setBounds(1000,120,250,50);
     add(button);
     add(button1);
     add(button2);
     add(button3);
     add(h);
     add(bp);
    addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }
  public static void main(String[] args) {new homepage().setVisible(true);}
}
class BackgroundPanel extends Panel
{
  Image img;
  public BackgroundPanel()
  {
    try
    {
      img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("n3.jpg"), "n3.jpg"));
    }
    catch(Exception e){/*handled in paint()*/}
  }
  public void paint(Graphics g)
  {
    super.paint(g);
    if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
    else g.drawString("No Image",100,100);
  }
}  
