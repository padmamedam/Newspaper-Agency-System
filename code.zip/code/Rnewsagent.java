
import java.awt.Color;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sabitha
 */
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Rnewsagent extends JFrame implements ActionListener{
   JButton b1,back;
   JTextField c1;
    Rnewsagent(){
        JLabel l0 = new JLabel("Removing NewsAgent");
        l0.setForeground(Color.red);
        l0.setFont(new Font("Serif", Font.BOLD, 20));
        JLabel l1 = new JLabel("Enter newsagent ID");
        b1 = new JButton("submit");
        back = new JButton("back");
        c1= new JTextField();
        l0.setBounds(100, 50, 350, 40);
        l1.setBounds(75, 110, 250, 20);
        b1.setBounds(150, 150, 150, 20);
        back.setBounds(0,0,70,20);
        b1.addActionListener(this);
        back.addActionListener(this);
        c1.setBounds(270, 110, 150, 20);
        setLayout(null);
        setVisible(true);
        setSize(500, 500);
        ResultSet rs;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(l0);
        add(l1);;
        add(b1);
        add(c1);
        add(back);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        { 
            int x = 0;  
            String s1 = c1.getText();  
                    try  
                    {  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        System.out.println("Success");
                        PreparedStatement pst;
                        pst = con.prepareStatement("DELETE from reg1 where nid=?");
                        pst.setString(1,s1);
                        pst.executeUpdate();
                        x++;  
                        if (x > 0)   
                        {  
                            JOptionPane.showMessageDialog(b1, "successfully deleted"); 
                        }  
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }  
                }  
        if(e.getSource()==back)
        {
            Manager man2=new Manager();
	    setVisible(false);
	    man2.setVisible(true);
        }          
        }
     public static void main(String args[]) throws IOException { 
        new Rnewsagent();
    }

}
  
