/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.*;
class Editpaper extends JFrame implements ActionListener
{
  JButton button,button1,button2;
  public Editpaper()
  {
    setSize(1200,700);
   // setLocation(400,300);
    BackgroundPanel bp = new BackgroundPanel();
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    button= new JButton("Remove Newspaper");
    button1= new JButton("Change Cost");
    button2= new JButton("Back");
   
    button.setBounds(80,100,200,50);
    button1.setBounds(350,100,150,50);  
    button2.setBounds(570,100,150,50);
    
     add(button);
     add(button1);
     add(button2);
     add(bp);
    
   
     button.addActionListener(this);
     button1.addActionListener(this);
     button2.addActionListener(this);
    
  }
  public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==button)
        { 
            	
				Rpaper ln;
                                ln = new Rpaper();
                                setVisible(false);
                                ln.setVisible(true);
				
        
        }
        if(e.getSource()==button1)
        { 
            	
				Cpaper ln;
                                ln = new Cpaper();
                                setVisible(false);
                                ln.setVisible(true);
				
        }
        
        if(e.getSource()==button2)
        { 
            	
				NewsAgent NA;
                                NA = new NewsAgent();
                                setVisible(false);
                                NA.setVisible(true);
				
        }
       
    }
  public static void main(String[] args) {new Editpaper().setVisible(true);}
}
class BackgroundPanel0 extends Panel
{
  Image img;
  public BackgroundPanel0()
  {
    try
    {
      img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("n3.jpg"), "n3.jpg"));
    }
    catch(Exception e){/*handled in paint()*/}
  }
  public void paint(Graphics g)
  {
    super.paint(g);
    if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
    else g.drawString("No Image",100,100);
  }
}  
