
import java.awt.Color;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sabitha
 */
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Cpaper extends JFrame implements ActionListener{
   JButton b1,b2;
   JTextField c1,c2;
    Cpaper(){
        JLabel l0 = new JLabel("Changing Cost");
        l0.setForeground(Color.red);
        l0.setFont(new Font("Serif", Font.BOLD, 20));
        JLabel l1 = new JLabel("Enter newspaper name");
        JLabel l2=new JLabel("Enter Cost");
        b1 = new JButton("submit");
        b2=new JButton("back");
        c1= new JTextField();
        c2=new JTextField();
        l0.setBounds(100, 50, 350, 40);
        l1.setBounds(75, 110, 120, 20);
        l2.setBounds(75, 150, 130, 20);
        b1.setBounds(100,190,100,30);
        b2.setBounds(220,190,100,30);
        b1.addActionListener(this);
        b2.addActionListener(this);
        c1.setBounds(200, 110, 150, 20);
        c2.setBounds(200,150,150,20);
        setLayout(null);
        setVisible(true);
        setSize(500, 500);
        ResultSet rs;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(l0);
        add(l1);;
        add(b1);
        add(c1);
        add(c2);
        add(l2);
        add(b2);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        { 
            int x = 0;  
            String s1 = c1.getText();
            String s3=c2.getText();
            int s2= Integer.parseInt(s3);		
                    try  
                    {  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        System.out.println("Success");
                        PreparedStatement pst;
                        pst = con.prepareStatement("Update newspaper set Cost='"+s2+"' where papername=?");
                        pst.setString(1,s1);
                       // pst.setString(2,s2);
                        int rs1;
                        rs1=pst.executeUpdate();
                        
                        
                        if (rs1> 0)   
                        {  
                            JOptionPane.showMessageDialog(b1, "successfully Modified"); 
                        } 
                        else
                        {
                            JOptionPane.showMessageDialog(b1, "News Paper Not Found!Enter Correctly"); 
                        }
                              
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }  
                }  
                if(e.getSource()==b2)
                {
                              Editpaper ln;
                                ln = new Editpaper();
                                setVisible(false);
                                ln.setVisible(true);
                }
        }
     public static void main(String args[]) throws IOException { 
        new Cpaper();
    }

}
  
