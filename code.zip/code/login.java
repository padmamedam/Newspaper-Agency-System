/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RGUKT
 */
import javax.swing.*; 
import java.awt.*;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
public class login extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4;
    JTextField tf1,tf2;
    //JPasswordField tf2;
    JButton btn1,btn2,b3,back;
    String uid;
    static String uid1;
    login() throws IOException
    {
        setVisible(true);  
        setSize(700, 700);  
        setLayout(null);  
       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
            setTitle("Customer Login Form");  
            l1 = new JLabel("Customer Login Form ");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            
            l2 = new JLabel("User ID:");  
            l3 = new JLabel("Password");  
            tf1 = new JTextField("");  
            tf2 = new JPasswordField("");   
            
            btn1 = new JButton("Login");  
            btn2 = new JButton("New User");  
            back=new JButton("Back");
            l1.setBounds(150, 30, 400, 30);  
            l2.setBounds(80, 100, 200, 30);  
            l3.setBounds(80, 150, 200, 30);  
          
           
            tf1.setBounds(300, 100, 200, 30);  
            tf2.setBounds(300, 150, 200, 30); 
            btn1.setBounds(120, 250, 100, 30);  
            btn2.setBounds(280, 250, 150, 30);
            back.setBounds(0,0,80,30);
       
  
        this.add(tf1);
        this.add(tf2);
        this.add(btn1);
        this.add(btn2);
        this.add(l1);
        this.add(l2);
        this.add(l3);
        this.add(back);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        back.addActionListener(this);
        //b3.addActionListener(this);
        uid1=tf1.getText();
        //viewinfo page=new viewinfo(str);
         
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==btn1)
        {
            
            String uid=tf1.getText();
            String password=tf2.getText();
            Connection con=null;
            Statement st = null;
                
                 try
                 {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                    st=con.createStatement(); 
      
                    ResultSet rs=st.executeQuery("select * from reg where cid='"+uid+"' and pwd='"+password+"'");
                    
                    
                    if(rs.next())
                    {              
                        String username = rs.getString("cid");
                        String passwd = rs.getString("pwd");
                        if (uid.equals(username) && password.equals(passwd))
                        {
                            setVisible(false);
                            System.out.println("login successfull");
                            Customer page=new Customer(uid);
                            page.setVisible(true);
                            
                        }
                        else
                        {

                            JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                            //tf1.setText("");
                            //tf2.setText("");
                            //tf1.requestFocusInWindow();
                         }
                       // setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    }   

                } 
                 catch (SQLException ex)
                 { 
                    Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
                 catch (ClassNotFoundException ex)
                 {
                        Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
         }
        else if(ae.getSource()==btn2)
        {
            try {
                dispose();
                Registration c=new Registration();
                //dispose();
                //PreparedStatement ps=con.prepareStatement("update login set User="" from login where User=? and Password=?");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(ae.getSource()==back)
        {
            	homepage ln;
                            
                                ln = new homepage();
                                setVisible(false);
				ln.setVisible(true);
                           
        }
       }     
    
    public static void main(String[] args) throws IOException 
    { 
        login man1=new login();
        man1.setSize(1300,950); 
        man1.setVisible(true);
    }   
}