/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author b141477
 */
//package newspaper;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
class Manager extends  JFrame implements ActionListener   
{
    String mid;
  public Manager()
  {
    this.mid=mid;
    setSize(1300,700);
    setLocation(400,300);
    BackgroundPanell bp = new BackgroundPanell();
    JButton button= new JButton("Customer Details");
    JButton button1= new JButton("NewsAgent Details");
    JButton button5= new JButton("Logout");
    JButton button2=new JButton("Add NewsAgent");
    JButton button3=new JButton("Remove NewsAgent");
    JButton button4=new JButton("Remove Customer");
    //JButton button3= new JButton("Edit Myinfo");
    //button.setBounds(100,100,180,50);
    //button1.setBounds(300,100,180,50);
    //button2.setBounds(600,700,80,20);
    //button3.setBounds(900,700,80,20);
    
    button.setBounds(0,100,200,50);
     button1.setBounds(220,100,250,50);
     button2.setBounds(490,100,250,50);
     button3.setBounds(760,100,250,50);
     button4.setBounds(1030,100,250,50);
     button5.setBounds(0,0,100,50);
      
     add(button);
     add(button1);
     add(button2);
     add(button3);
     add(button4);
     add(button5);
     add(bp);
     
      button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Viewinfo2 man2 = null;
                            try {
                                man2 = new Viewinfo2();
                            } catch (Exception ex) {
                                Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
                            }
				setVisible(false);				
                               // dispose();
				
			}
		});
      
        button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Viewnew man1 = null;
                            try {
                                man1 = new Viewnew();
                            } catch (Exception ex) {
                                Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
                            }
				setVisible(false);
				//man1.setVisible(true);
                                //dispose();
				
			}
		});
      
     
     button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Registration1 man1 = null;
                            try {
                                man1 = new Registration1();
                            } catch (ClassNotFoundException ex) {
                                Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
                            }
				setVisible(false);
				man1.setVisible(true);
                               // dispose();
				
			}
		});
     
     
     
      button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				homepage man2=new homepage();
				setVisible(false);
				man2.setVisible(true);
                                //dispose();
				
			}
		});
     button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Rnewsagent man2=new Rnewsagent();
				setVisible(false);
				man2.setVisible(true);
                                //dispose();
				
			}
		});
     
     
     button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Rcustomer man3=new Rcustomer();
				setVisible(false);
				man3.setVisible(true);
                                //dispose();
				
			}
		});
     
     
  }
  public static void main(String[] args) {new Manager().setVisible(true);}

    void addActionListener(ActionListener actionListener) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
class BackgroundPanell extends Panel
{
  Image img;
  public BackgroundPanell()
  {
    try
    {
      img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("ns2.jpg"), "ns2.jpg"));
    }
    catch(Exception e){/*handled in paint()*/}
  }
  public void paint(Graphics g)
  {
    super.paint(g);
    if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
    else g.drawString("No Image",100,100);
  }
}  
