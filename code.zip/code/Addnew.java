/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RGUKT
 */
import javax.swing.*; 
import java.awt.*;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;



    import javax.swing.*;  
    import java.awt.*;  
    import java.awt.event.*;  
import java.io.IOException;
    import java.sql.*;  
import java.text.ParseException;
import java.text.SimpleDateFormat;
    //import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
    
import java.text.ParseException;  
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.Locale;   
public class Addnew extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4,l5,at,bt;
    JTextField tf2,tf5;
     JComboBox tf1;
    JButton btn1,btn2,b3,back;
     String s,sc;
    String paper[] =new String[7];
    
    Addnew() throws IOException
    {
        setVisible(true);  
        setSize(700, 1200);  
        setLayout(null);  
       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
            setTitle("Adding newspaper");  
            
            Random rnd = new Random();
            int n=100000+rnd.nextInt(900000);
            
            l1 = new JLabel("ADD NEWS PAPER");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            
           
            l2 = new JLabel("Newspaper name:");  
            l3 = new JLabel("Cost"); 
            
            tf1 = new JComboBox();
            tf2 = new JTextField("");   
            
            at=new JLabel("");
            at.setBounds(550,150,300,40);
            
            bt=new JLabel("");
            bt.setBounds(550,100,300,40);
         
            btn1 = new JButton("Submit");  
            back=new JButton("Back");
            
            l1.setBounds(150, 30, 400, 30);  
            l2.setBounds(80, 100, 200, 30);  
            l3.setBounds(80, 150, 200, 30);  
             
            tf1.setBounds(300, 100, 200, 30);  
            tf2.setBounds(300, 150, 200, 30); 
            btn1.setBounds(120, 250, 100, 30);  
           
            back.setBounds(0,0,80,30);
       
            
            
            
            paper[1]="eenadu";         
            paper[2] = "sakshi";
            paper[3] = "namastetelangana";
            paper[4] = "andhrajyothi";
            paper[5] = "deccanchronicle";
            paper[6] = "the times of india";
            for (int j= 1; j< 7; j++) {
                tf1.addItem(paper[j]); 
        } 
            
        this.add(at); 
        this.add(bt);
        this.add(tf1);
        this.add(tf2);
        this.add(btn1);
        //this.add(btn2);
        this.add(l1);
        this.add(l2);
        this.add(l3);
        this.add(back);
        //this.add(l5);
        //this.add(tf5);
        btn1.addActionListener(this);
        //btn2.addActionListener(this);
        back.addActionListener(this);
        //b3.addActionListener(this); 
      
        
            
            
            
       
    }
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==btn1)
        {
            try {
                if(reg()){
                    int x=0;
                    Object selectedStateobj = tf1.getSelectedItem();
                    String selectedState = String.valueOf(selectedStateobj);
                    String s1= selectedState;
                    String s2=tf2.getText();
                    //String s3=tf5.getText();
                    try
                    {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                        System.out.println("Success");
                        PreparedStatement ps = con.prepareStatement("insert into newspaper(papername,cost) values(?,?)");
                        
                        ps.setString(1, s1);
                        ps.setString(2, s2);
                        int rs = ps.executeUpdate();
                        x++;
                        if (x > 0)
                        {
                            JOptionPane.showMessageDialog(btn1, "Data Saved Successfully");  
                        }
                    }
                    catch (Exception ex)
                    {
                        System.out.println(ex);
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(Addnew.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(ae.getSource()==back)
        {
             NewsAgent ln0 = null;
          try {
              ln0 = new NewsAgent();
          } catch (Exception ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                setVisible(false);
                ln0.setVisible(true);
        }
    }
    public static void main(String[] args) throws IOException 
    { 
        Addnew man = new Addnew();
        man.setSize(1300,950); 
        man.setVisible(true);
       
    } 
    
      public static boolean isamount(String s) 
            { 
                    String pattern = "^(2[0]|1[0-9]|[1-9])$";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
            }
      
         public boolean reg() throws SQLException{
            
            String amount =tf2.getText();
           
            Object selectedStateobj = tf1.getSelectedItem();
                String selectedState = String.valueOf(selectedStateobj);
                 s= selectedState;
                 
             
            if(isamount(amount))
            {
               at.setText("");
            }
            else{
               at.setText("paper cost should be within 1 to 20 rupees");
            tf2.requestFocusInWindow();
            return false;
            }
            
            
            
            
            
                Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                Statement st2 = con1.createStatement();               
                ResultSet rs2=st2.executeQuery("select * from newspaper where papername='"+s+"'");
                        if(rs2.next())
                        {
                            sc=rs2.getString("papername");
                              
                        }
                
            
            if(s.equals(sc))
            {
                
                bt.setText("Already this paper is Added");
                tf1.requestFocusInWindow();
                return false;
            }
            else
            {
                bt.setText("");
            }
            
            
          
            return true;
         }  
            
}