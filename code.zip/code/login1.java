/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RGUKT
 */
import javax.swing.*; 
import java.awt.*;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
public class login1 extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4;
    
    JTextField tf1,tf2;
    //JPasswordField tf2;
    JButton btn1,btn2,back;
    String uname,username;
    
    login1() throws IOException
    {
        setVisible(true);  
        setSize(700, 700);  
        setLayout(null);  
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
            setTitle("Newsagent Login Form");  
            l1 = new JLabel("Newsagent Login Form ");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            
            l2 = new JLabel("Newsagent ID:");  
            l3 = new JLabel("Password");  
            tf1 = new JTextField("");  
            tf2 = new JPasswordField("");   
            
            back=new JButton("back");
            btn1 = new JButton("Login");  
            btn2 = new JButton("Change password");  
           
             back.setBounds(0,0,70,30);
            l1.setBounds(150, 30, 400, 30);  
            l2.setBounds(80, 100, 200, 30);  
            l3.setBounds(80, 150, 200, 30);  
          
            
            tf1.setBounds(300, 100, 200, 30);  
            tf2.setBounds(300, 150, 200, 30); 
            btn1.setBounds(120, 250, 100, 30);  
            btn2.setBounds(280, 250, 150, 30); 
            
       
  
        this.add(tf1);
        this.add(tf2);
        this.add(btn1);
        this.add(btn2);
        this.add(l1);
        this.add(l2);
        this.add(l3);
        this.add(back);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        back.addActionListener(this);  
       
    }
    public void actionPerformed(ActionEvent ae)
    {
        
          uname=tf1.getText();
           String password=tf2.getText();
        if(ae.getSource()==btn1)
        {
             //uname=tf1.getText();
            //String password=tf2.getText();
            
            Connection con=null;
            Statement st = null;
                
                 try
                 {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                    st=con.createStatement(); 
      
                    ResultSet rs=st.executeQuery("select * from reg1 where nid='"+uname+"' and pwd='"+password+"'");
                    
                    
                    if(rs.next())
                    {              
                        username = rs.getString("nid");
                       
                        String passwd = rs.getString("pwd");
                    
                

                        if (uname.equals(username) && password.equals(passwd))
                        {
                            setVisible(true);
                            System.out.println("login successfull");
                            NewsAgent page=new NewsAgent();
                            page.setVisible(true);
                            dispose();
                        }
                        else
                        {

                            JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                            //tf1.setText("");
                            //tf2.setText("");
                            //tf1.requestFocusInWindow();
                         }
                       
                    }
                     else
                    {
                        
                        JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                        //tf1.setText("");
                        //tf2.setText("");
                        //tf1.requestFocusInWindow();
                    }
                     //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                } 
                 catch (SQLException ex)
                 { 
                    Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
                 catch (ClassNotFoundException ex)
                 {
                        Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
              }    
         
        if(ae.getSource()==btn2)
        {
            Connection con=null;
            Statement st = null;
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                st=con.createStatement();
                
                ResultSet rs=st.executeQuery("select * from reg1 where nid='"+uname+"' and pwd='"+password+"'");
                
                
                if(rs.next())
                {
                    username = rs.getString("nid");
                    
                    String passwd = rs.getString("pwd");
                    
                    
                    
                    if (uname.equals(username) && password.equals(passwd))
                    {
                        setVisible(true);
                        System.out.println("login successfull");
                        Changepassword page=new Changepassword(username);
                        page.setVisible(true);
                        dispose();
                    }
                    else
                    {
                        
                        JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                        //tf1.setText("");
                        //tf2.setText("");
                        //tf1.requestFocusInWindow();
                    }
                    
                }
                 else
                    {
                        
                        JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                        //tf1.setText("");
                        //tf2.setText("");
                        //tf1.requestFocusInWindow();
                    }
                //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                
            }
            catch (SQLException ex)
            {
                Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (ClassNotFoundException ex)
            {
                Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                  Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
              }
        }
        if(ae.getSource()==back)
        {
            homepage lnm;
           lnm = new homepage();
           setVisible(false);
           lnm.setVisible(true);
           dispose();
        }
        
}
    public static void main(String[] args) throws IOException 
    { 
        login1 man1=new login1();
        man1.setSize(1300,950); 
        man1.setVisible(true);
        man1.addWindowListener(new WindowAdapter()
        {
            public void WindowClosing(WindowEvent e)
            {
                System.exit(0);
             }
        });
    }
    
}