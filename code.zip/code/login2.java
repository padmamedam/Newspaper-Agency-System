//package newspaper;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


 
public class login2 extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4;
    
    JTextField tf1;
    JPasswordField tf2;
    JButton btn1,back;
    String mid;
    login2() throws IOException
    {
        setVisible(true);  
        setSize(700, 700);  
        setLayout(null);  
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
            setTitle("Manager Login Form");  
            l1 = new JLabel("Manager Login Form");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            
            l2 = new JLabel("User Name:");  
            l3 = new JLabel("Password");  
            tf1 = new JTextField("");  
            tf2 = new JPasswordField("");   
            
            btn1 = new JButton("Login");  
            back=new JButton("Back");
            //btn2 = new JButton("New User");  
 
            l1.setBounds(150, 30, 400, 30);  
            l2.setBounds(80, 100, 200, 30);  
            l3.setBounds(80, 150, 200, 30);  
          
           
            tf1.setBounds(300, 100, 200, 30);  
            tf2.setBounds(300, 150, 200, 30); 
            btn1.setBounds(200, 250, 100, 30);  
            back.setBounds(0,0,70,30);
            //btn2.setBounds(280, 250, 150, 30);  
       
  
        this.add(tf1);
        this.add(tf2);
        this.add(btn1);
        this.add(back);
        this.add(l1);
        this.add(l2);
        this.add(l3);
        
        btn1.addActionListener(this);
        back.addActionListener(this);
        //btn2.addActionListener(this);
        //b3.addActionListener(this);  
       
    }
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==btn1)
        {
            
            mid=tf1.getText();
            String uname=tf1.getText();
            String password=tf2.getText();
            String mid="Admin123";
            String mpass="rgukt123";
            //Connection con=null;
            //Statement st = null;
                
                 try
                 {
                    
                        if (uname.equals(mid) && password.equals(mpass))
                        {
                            setVisible(true);
                            System.out.println("login successfull");
                            Manager page=new Manager();
                            page.setVisible(true);
                            dispose();
                        }
                        else
                        {

                            JOptionPane.showMessageDialog(null,"Incorrect login or password","Error",JOptionPane.ERROR_MESSAGE);
                            //tf1.setText("");
                            //tf2.setText("");
                            //tf1.requestFocusInWindow();
                         }
                       
                    }catch (Exception ex)
                    { 
                       Logger.getLogger(login2.class.getName()).log(Level.SEVERE, null, ex);
                    } 
            }  
                    
                     //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        if(ae.getSource()==back)
        {
           homepage ln;
           ln = new homepage();
           setVisible(false);
           ln.setVisible(true);
           dispose();
        }
    }
    
    public static void main(String[] args) throws IOException 
    { 
        login2 man2=new login2();
        man2.setSize(1300,950); 
    man2.setVisible(true);
        man2.addWindowListener(new WindowAdapter()
        {
            public void WindowClosing(WindowEvent e)
            {
                System.exit(0);
             }
        });
    } 
    
    
    
    public static boolean ispass(String s) 
     { 
        
        Pattern p=Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
     
   
        Matcher mtch = p.matcher(s);
        if(mtch.matches()){
            return true;
        }
        return false;
      }
       
            public boolean reg(){
            
            String Passwd = tf2.getText();
            
          
           
            if(ispass(Passwd))
            {}
            else{
            JOptionPane.showMessageDialog(null,"Password must contain length atleast 6 & one capital letter,special symbol and one digit ");
            tf1.requestFocusInWindow();
            return false;
            }
           
            return true;
         }
    
}