
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

import java.text.ParseException;  
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.Locale;  
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar; 
import java.util.Date; 
import java.util.Calendar; 
import java.text.DateFormat;
public class Updatecstatus {
    
    String s,s3,s4;
    Date d3=null;
    Date d1=null;
    java.sql.Date date;
    
    Updatecstatus() throws ParseException{
     try {  
              Class.forName("com.mysql.cj.jdbc.Driver");
              Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", ""); 
              PreparedStatement pst = con.prepareStatement("select * from reg");
              ResultSet rs = pst.executeQuery();
              
              SimpleDateFormat format = null ;
            
                  Date date3 = new Date();  
                 SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
                 String strDate1 = formatter.format(date3);  
                 long current = Date.parse(strDate1);
                 
                 //System.out.println(""+d3);
                  int count=0;
                  SimpleDateFormat formatter1;
                  
              while(rs.next())
              {
                 
                  s4=rs.getString("cid");
                  String s =rs.getString("date");
                 // System.out.println(""+s);
                  Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(s);
                   String d1 = formatter.format(date1);  
                    long dd = Date.parse(d1);        
                    long diff1 = current-dd;
                    long days = diff1 / (24 * 60 * 60 * 1000);
                  // System.out.println(days);
                  //Calendar c=Calendar.getInstance();
                  
                   //long diff = 0;
                 //diff = date1.getTime - date1.getTime();
                  //long diffDays = diff / (24 * 60 * 60 * 1000);
                  if(days>=0)
                  {
                      if(days>=35)
                      {
                          String sy="UNPAID";
                                  PreparedStatement pst1;
                                  pst1 = con.prepareStatement("Update reg set Status='"+sy+"' where cid='"+s4+"'");
                                  //pst.setString(1,uid);                      
                                  int rs1;
                                  rs1 = pst1.executeUpdate();
                                  if(rs1>0){
                                       count++;
                                  }
                      }
                  }
                 
              }
              if(count>=0)
              {
                 Update ln=new Update();
              }
              
              
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          } catch (SQLException ex) {
              Logger.getLogger(NewsAgent.class.getName()).log(Level.SEVERE, null, ex);
          }
                       
      }

    

   
   
    
  }
    

