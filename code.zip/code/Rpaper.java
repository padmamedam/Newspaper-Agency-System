
import java.awt.Color;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sabitha
 */
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Rpaper extends JFrame implements ActionListener{
   JButton b1,b2;
   JTextField c1;
    Rpaper(){
        JLabel l0 = new JLabel("Removing Newspaper");
        l0.setForeground(Color.red);
        l0.setFont(new Font("Serif", Font.BOLD, 20));
        JLabel l1 = new JLabel("newspaper name");
        b1 = new JButton("submit");
        b2=new JButton("back");
        c1= new JTextField();
        l0.setBounds(100, 50, 350, 40);
        l1.setBounds(75, 110, 180, 20);
        b1.setBounds(150, 150, 100, 20);
        b2.setBounds(300,150,100,20);
        b1.addActionListener(this);
        b2.addActionListener(this);
        c1.setBounds(250, 110, 180, 20);
        setLayout(null);
        setVisible(true);
        setSize(500, 500);
        ResultSet rs;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(l0);
        add(l1);;
        add(b1);
        add(c1);
        add(b2);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        { 
            int x = 0;  
            String s1 = c1.getText();  
                    try  
                    {  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        System.out.println("Success");
                        PreparedStatement pst;
                        pst = con.prepareStatement("DELETE from newspaper where papername=?");
                        pst.setString(1,s1);
                        int rs1;
                        rs1=pst.executeUpdate();
                        if(rs1>0)   
                        {
                            JOptionPane.showMessageDialog(b1, "successfully deleted");
                        } else { 
                            JOptionPane.showMessageDialog(b1, "NewsPaper Not found!Enter Correctly");
                        }  
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }  
                }  
                if(e.getSource()==b2)
                {
                    Editpaper ln;
                    ln = new Editpaper();
                     setVisible(false);
                      ln.setVisible(true);
                }
        }
     public static void main(String args[]) throws IOException { 
        new Rpaper();
    }

}
  
