
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JPasswordField;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */

public class Changepassword extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4;
    JTextField tf1,tf2;
    //JPasswordField tf2;
    JButton btn1,btn2,b3,back;
    String uid;
    static String uid1;
    String uname;
    Changepassword(String uname) throws IOException
    {
        this.uname=uname;
        setVisible(true);  
        setSize(700, 700);  
        setLayout(null);  
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
            setTitle("change password");  
            l1 = new JLabel("change password");  
            l1.setForeground(Color.blue);  
            l1.setFont(new Font("Serif", Font.BOLD, 20));  
            
            l2 = new JLabel("password:");  
            l3 = new JLabel("confirm password");  
            tf1 = new JPasswordField("");  
            tf2 = new JPasswordField("");  
            btn1 = new JButton("change password");  
            btn2 = new JButton("Back");  
           
            l1.setBounds(150, 30, 400, 30);  
            l2.setBounds(80, 100, 200, 30);  
            l3.setBounds(80, 150, 200, 30);  
          
           
            tf1.setBounds(300, 100, 200, 30);  
            tf2.setBounds(300, 150, 200, 30); 
            btn1.setBounds(120, 250, 100, 30);  
            btn2.setBounds(280, 250, 150, 30);
            
       
  
        this.add(tf1);
        this.add(tf2);
        this.add(btn1);
        this.add(btn2);
        //this.add(l1);
        this.add(l2);
        this.add(l3);
       
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        //back.addActionListener(this);
        //b3.addActionListener(this);
        //uid1=tf1.getText();
        //viewinfo page=new viewinfo(str);
      //  System.out.println(""+uname);
         
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==btn1)
        {
          if(reg()){
            String p1=tf1.getText();
            String p2=tf2.getText();
            Connection con=null;
            Statement st = null;
                 try
                 {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
                    //st=con.createStatement(); 
                    if(p1.equals(p2)){
                     PreparedStatement pst1;
                                  pst1 = con.prepareStatement("Update reg1 set pwd='"+p1+"',cpwd='"+p2+"' where nid='"+uname+"'");
                                  //pst.setString(1,uid);                      
                                  int rs1;
                                  rs1 = pst1.executeUpdate();
                                  if(rs1>0){
                                       
                               
                                        JOptionPane.showMessageDialog(null,"password changed successfully","Error",JOptionPane.ERROR_MESSAGE);
                              
                                  
                    }
                    
                    }
                 }
                 catch (SQLException ex)
                 { 
                    Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
                 catch (ClassNotFoundException ex)
                 {
                        Logger.getLogger(login1.class.getName()).log(Level.SEVERE, null, ex);
                 } 
        }
        
        }
                tf1.setText("");  
                tf2.setText(""); 
              
                    
          if(ae.getSource()==btn2)
        {
            	NewsAgent ln;
                            
                                ln = new NewsAgent();
                                setVisible(false);
				ln.setVisible(true);
                           
        }
    }
    
    
    
     public static boolean ispass(String s) 
     { 
        
        Pattern p=Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
     
   
        Matcher mtch = p.matcher(s);
        if(mtch.matches()){
            return true;
        }
        return false;
      }
       
            public boolean reg(){
            
            String Passwd = tf1.getText();
            String Cpasswd =tf2.getText();
          
           
            if(ispass(Passwd))
            {}
            else{
            JOptionPane.showMessageDialog(null,"Password must contain length atleast 6 & one capital letter,special symbol and one digit ");
            tf1.requestFocusInWindow();
            return false;
            }
           
            return true;
         }
   
 }
    