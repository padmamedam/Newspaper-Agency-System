/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Viewnew extends JFrame implements ActionListener{

    JButton b2;
    JFrame frame1;
    Connection con;
    ResultSet rs, rs1;
    Statement st, st1;
    PreparedStatement pst;
    String ids;
    static JTable table;
    String[] columnNames = {"News AgentID","Newsagent name", "Email", "Password","confirm password" ,"address","state","phone_no"};
    Viewnew() throws Exception{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
            showTableData();
       }
    
    public void showTableData() {
//TableModel tm = new TableModel();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
//DefaultTableModel model = new DefaultTableModel(tm.getData1(), tm.getColumnNames());
//table = new JTable(model);
            frame1 = new JFrame("Database Search Result");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame1.setLayout(new BorderLayout());
        frame1.setLayout(null);
        table = new JTable();
        table.setModel(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setFillsViewportHeight(true);
        table.setEnabled(false);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
    
       
      
         
        
        
//String textvalue = textbox.getText();
        String nid="";
        String name = "";
        String email = "";
        String pass = "";
        String cou = "";
        String address = "";
        String state="";
        String phoneno = "";
        try {
            pst = con.prepareStatement("select * from reg1");
            ResultSet rs = pst.executeQuery();
            int i = 0;
            while (rs.next()) {
                 nid=rs.getString("nid");
                name = rs.getString("name");
                email = rs.getString("emailid");
                pass = rs.getString("pwd");
                cou = rs.getString("cpwd");
                address = rs.getString("address");
                state=rs.getString("state");
                phoneno = rs.getString("phoneno");
                //newspaper = rs.getString("newspaper");
                //status=rs.getString("Status");
                model.addRow(new Object[]{nid,name, email, pass, cou,address,state,phoneno});
                
                
               
                i++;
            }
            if (i < 1) {
                JOptionPane.showMessageDialog(null, "No Record Found", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if (i == 1) {
                System.out.println(i + " Record Found");
            } else {
                System.out.println(i + " Records Found");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        scroll.setBounds(5,40,1300,600);
        b2 = new JButton("Back");
        b2.setBounds(5, 0, 100, 37);
        frame1.add(scroll);        
        frame1.setSize(1500, 700);
        frame1.setVisible(true);
        frame1.add(b2);
        b2.addActionListener(this);
        
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b2)
        { 
            	                frame1.dispose();
				Manager ln;
                                ln = new Manager();
                                setVisible(false);
                                ln.setVisible(true);
                                dispose();
				
        }
    }
    
    
    public static void main(String args[]) throws Exception{
        new Viewnew();
    }

    


    
}