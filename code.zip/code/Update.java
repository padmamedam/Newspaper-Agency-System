
import java.awt.Color;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sabitha
 */
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Update extends JFrame implements ActionListener{
   JButton b1,b2;
   JTextField c1,c2;
    Update(){
        JLabel l0 = new JLabel("Updated Successsfully");
        l0.setForeground(Color.red);
        l0.setFont(new Font("Serif", Font.BOLD, 20));
       
        b2=new JButton("back");
     
        l0.setBounds(100, 50, 350, 40);
       
        b2.setBounds(0,0,100,30);
       
        b2.addActionListener(this);
      
        setLayout(null);
        setVisible(true);
        setSize(500, 500);
      
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(l0);
         
        add(b2);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b2)
        { 
            	
				NewsAgent ln;
                                ln = new NewsAgent();
                                setVisible(false);
                                ln.setVisible(true);
                                dispose();
				
        }
    }
     public static void main(String args[]) throws IOException { 
        new Update();
    }

}
  
