
import java.awt.Color;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sabitha
 */
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Rcustomer extends JFrame implements ActionListener{
   JButton b1,back;
   JTextField c1;
    Rcustomer(){
        JLabel l0 = new JLabel("Removing Customer");
        l0.setForeground(Color.red);
        l0.setFont(new Font("Serif", Font.BOLD, 20));
        JLabel l1 = new JLabel("Enter Customer ID");
        b1 = new JButton("submit");
        c1= new JTextField();
        back=new JButton("Back");
        l0.setBounds(100, 50, 350, 40);
        l1.setBounds(75, 110, 250, 20);
        b1.setBounds(150, 150, 150, 20);
        back.setBounds(0,0,70,20);
        b1.addActionListener(this);
        back.addActionListener(this);
        c1.setBounds(270, 110, 150, 20);
        setLayout(null);
        setVisible(true);
        setSize(500, 500);
        ResultSet rs;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(l0);
        add(l1);;
        add(b1);
        add(back);
        add(c1);
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        { 
            int x = 0;  
            String s1 = c1.getText();  
                    try  
                    {  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        System.out.println("Success");
                        PreparedStatement pst;
                        pst = con.prepareStatement("DELETE from reg where cid=?");
                        pst.setString(1,s1);
                        pst.executeUpdate();
                        x++;  
                        if (x > 0)   
                        {  
                            JOptionPane.showMessageDialog(b1, "successfully deleted"); 
                        }  
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }
        }
               /* else  
                {  
                    JOptionPane.showMessageDialog(b1, "something went wrong");  
                }*/
        if(e.getSource()==back)
        {
            Manager man2=new Manager();
	    setVisible(false);
	    man2.setVisible(true);
        }                         
        }
     public static void main(String args[]) throws IOException { 
        new Rcustomer();
    }

}
  
