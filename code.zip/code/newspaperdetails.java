/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class newspaperdetails extends JFrame implements ActionListener{

    JButton b2;
    JFrame frame1;
    Connection con;
    ResultSet rs, rs1;
    Statement st, st1;
    PreparedStatement pst;
    String ids;
    static JTable table;
    String[] columnNames = {"papername", "cost"};
    newspaperdetails() throws Exception{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
            showTableData();
       }
    
    public void showTableData() {
//TableModel tm = new TableModel();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
//DefaultTableModel model = new DefaultTableModel(tm.getData1(), tm.getColumnNames());
//table = new JTable(model);
            frame1 = new JFrame("Database Search Result");
        
        //frame1.setLayout(new BorderLayout());
        frame1.setLayout(null);
        table = new JTable();
        table.setModel(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setFillsViewportHeight(true);
        table.setEnabled(false);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
    
       
      
         
        
        
//String textvalue = textbox.getText();
        String papername = "";
        String cost = "";
        
        try {
            pst = con.prepareStatement("select * from newspaper");
            ResultSet rs = pst.executeQuery();
            int i = 0;
            while (rs.next()) {
                papername = rs.getString("papername");
                cost = rs.getString("cost");
               
                model.addRow(new Object[]{papername, cost});
                
                
               
                i++;
            }
            if (i < 1) {
                JOptionPane.showMessageDialog(null, "No Record Found", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if (i == 1) {
                System.out.println(i + " Record Found");
            } else {
                System.out.println(i + " Records Found");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        scroll.setBounds(5,40,1300,600);
        b2 = new JButton("Back");
        b2.setBounds(5, 0, 100, 37);
        frame1.add(scroll);        
        frame1.setSize(1500, 700);
        frame1.setVisible(true);
        frame1.add(b2);
        b2.addActionListener(this);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE );
        
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b2)
        { 
            	              //  JTable.close();
                                frame1.dispose();
				homepage ln;
                                ln = new homepage();
                                setVisible(false);
                                ln.setVisible(true);
                                dispose();
				
        }
    }
    
    
    public static void main(String args[]) throws Exception{
        new newspaperdetails();
    }

    


    
}