/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package news;

import java.io.IOException;
import java.io.InputStream;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DateFormat;
import java.util.Date;
import java.time.LocalDate; 
import java.text.DateFormat;  
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
class paybill  implements ActionListener   
{

    String uid;
    JLabel label,label1,label2,label3,label4,label5,s3,label6,label7,at,cn,edate,an,cv,dt;
    JPanel panel;
    JFrame jf;
    JButton register,back;
    JTextField textfield1,textfield2,textfield3,textfield4a,textfield4b,textfield4,tf;
    String AccountantName,mm,yy,dobb,CVV,CardNumber,ExpiredDate;
    static JTextField s;
    String s0;
    String sc;
    double amount=0,amount2=0;
    //Connection con1;
    //Statement st1;
    //int index,count;
    JDateChooser date;
    //JCalendar jcalendar;
     paybill(String uid)
    {
      
        this.uid=uid;
        jf=new javax.swing.JFrame("Registration Form");
        panel=new javax.swing.JPanel();
        jf.add(panel);
        panel.setBackground(new Color(191,239,255));
        panel.setLayout(null);
        jf.setSize(1000,1000);
        jf.show();
        
        date=new JDateChooser();
        date.setBounds(350,280,150,30);
        date.setDateFormatString("MM/dd/yyyy");
        //date.getJCalander
       date.getJCalendar().setMinSelectableDate(new Date());
      // date.setMaxSelectableDate(Date.valueOf(getThreeWeeksFromNow()));
        //Component Calendar = null;
       //date.add(JCalendar.DAY_OF_MONTH,15);
        panel.add(date);

        //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        label1=new javax.swing.JLabel("Customer ID");
        label1.setFont(new Font("Dialog", Font.BOLD, 24));
        label1.setBounds(100,40,280,40);
        panel.add(label1);

        label2=new javax.swing.JLabel("Amount");
        label2.setFont(new Font("Dialog", Font.BOLD, 20));
        label2.setBounds(100,80,280,40);
        panel.add(label2);

        label3=new javax.swing.JLabel("Accountant Name");
        label3.setFont(new Font("Dialog", Font.BOLD, 20));
        label3.setBounds(100,120,250,40);
        panel.add(label3);

        label4=new javax.swing.JLabel("Card Number");
        label4.setFont(new Font("Dialog", Font.BOLD, 20));
        label4.setBounds(100,160,200,40);
        panel.add(label4);
        
         at=new javax.swing.JLabel("");
        at.setFont(new Font("Dialog", Font.BOLD, 15));
        at.setBounds(550,80,300,40);
        at.setForeground(Color.red);
        panel.add(at);
        
        cn=new javax.swing.JLabel("");
        cn.setFont(new Font("Dialog", Font.BOLD, 15));
        cn.setBounds(550,160,300,40);
        cn.setForeground(Color.red);
        panel.add(cn);
        
        cv=new javax.swing.JLabel("");
        cv.setFont(new Font("Dialog", Font.BOLD, 15));
        cv.setBounds(550,200,300,40);
        cv.setForeground(Color.red);
        panel.add(cv);
        
        edate=new javax.swing.JLabel("");
        edate.setFont(new Font("Dialog", Font.BOLD, 15));
        edate.setBounds(550,240,300,40);
        edate.setForeground(Color.red);
        panel.add(edate);
        
        an=new javax.swing.JLabel("");
        an.setFont(new Font("Dialog", Font.BOLD, 15));
       an.setBounds(550,120,300,40);
       an.setForeground(Color.red);
        panel.add(an);
        
        dt=new javax.swing.JLabel("");
        dt.setFont(new Font("Dialog", Font.BOLD, 15));
        dt.setBounds(550,280,300,40);
        dt.setForeground(Color.red);
        panel.add(dt);

        label5=new javax.swing.JLabel("CVV");
        label5.setFont(new Font("Dialog", Font.BOLD, 20));
        label5.setBounds(100,200,200,40);
        panel.add(label5);
        
        label6=new javax.swing.JLabel("Expired Date");
        label6.setFont(new Font("Dialog", Font.BOLD, 20));
        label6.setBounds(100,240,200,40);
        panel.add(label6);
        
        s3=new javax.swing.JLabel("(MM/YYYY)");
        s3.setFont(new Font("Dialog", Font.BOLD, 16));
        s3.setBounds(500,240,150,30);
        panel.add(s3);

        textfield1=new javax.swing.JTextField();
        textfield1.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield1.setBounds(350,80,180,30);
        panel.add(textfield1);
        
        tf=new javax.swing.JTextField();
        tf.setFont(new Font("Dialog", Font.BOLD, 16));
        tf.setBounds(350,40,180,30);
        tf.setText(uid);
        panel.add(tf);
        tf.setEnabled(false);

        textfield2=new javax.swing.JTextField();
        textfield2.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield2.setBounds(350,120,180,30);
        panel.add(textfield2);

        textfield3=new javax.swing.JTextField();
        textfield3.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield3.setBounds(350,160,180,30);
        panel.add(textfield3);
         
        textfield4=new javax.swing.JPasswordField();
        textfield4.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield4.setBounds(350,200,180,30);
        panel.add(textfield4);

        textfield4a=new javax.swing.JTextField();
        textfield4a.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield4a.setBounds(350,240,40,30);
        panel.add(textfield4a);

        textfield4b=new javax.swing.JTextField();
        textfield4b.setFont(new Font("Dialog", Font.BOLD, 16));
        textfield4b.setBounds(400,240,80,30);
        panel.add(textfield4b);
        
        label7=new JLabel("Enter Date");
         label7.setFont(new Font("Dialog", Font.BOLD, 24));
        label7.setBounds(100,280,200,40);
        panel.add(label7);

        register = new javax.swing.JButton("Pay Bill");
        register.setFont(new Font("Dialog", Font.BOLD, 16));
        register.setBounds(250,320,100,30);
        panel.add(register);
        register.addActionListener(this);
        
         back= new javax.swing.JButton("back");
         back.setFont(new Font("Dialog", Font.BOLD, 16));
         back.setBounds(0,0,80,30);
         panel.add(back);
         back.addActionListener(this);
    }
   
       public void actionPerformed(ActionEvent e)
        {
           if (e.getSource() == register)  
             {  
                if(reg()){
                int x = 0;  
                String s1 = textfield2.getText();  
                String s2 = textfield3.getText();  
                String s3 = textfield4.getText();  
                String a = textfield4a.getText();  
                String b = textfield4b.getText();
                String l=tf.getText();
 
                String s4=a+b;
                String s5=textfield1.getText();
                //DateFormat df=new SimpleDateFormat("MM/dd/yyyy");
                //String s7=df.format(date.getDate());
                    try  
                    {  
                        Class.forName("com.mysql.cj.jdbc.Driver");  
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");  
                        //System.out.println("Success");
                        Statement st1 = con.createStatement();
                        ResultSet rs1=st1.executeQuery("select * from reg where cid='"+uid+"'");
                        if(rs1.next())
                        {
                            
                            System.out.println("Success");
                            s0=rs1.getString("newspaper");
                            
                        }
                        
                        Statement st2 = con.createStatement();               
                        ResultSet rs2=st2.executeQuery("select * from newspaper where papername='"+s0+"'");
                        if(rs2.next())
                        {
                            sc=rs2.getString("cost");
                              
                        }
                        
                        String amt=textfield1.getText();
                        double amt1=Double.parseDouble(amt);
                        
                        double amt2=Double.parseDouble(sc);
                        amount=amt2*30;
                        
                        
                        
                        
                        if(amount==amt1)
                        {
                            PreparedStatement ps = con.prepareStatement("insert into paybill(cid,amount,a_name,card_no,cvv,expired_date,date) values(?,?,?,?,?,?,?)");  
                            ps.setString(1,l);
                            ps.setString(2, s5);  
                            ps.setString(3, s1);
                            ps.setString(4, s2); 
                            ps.setString(5, s3); 
                            ps.setString(6,s4);
                            
                            DateFormat df=new SimpleDateFormat("MM/dd/yyyy");
                            String s7=df.format(date.getDate());
                            
                            ps.setString(7,s7);
                            int rs = ps.executeUpdate();  
                                  
                            x++;  
                            if (x > 0)   
                            {   
                                  String sy="PAID";
                                  PreparedStatement pst;
                                  pst = con.prepareStatement("Update reg set status='"+sy+"',date='"+s7+"' where cid='"+uid+"'");
                                  //pst.setString(1,uid);                      
                                  int rs0;
                                  rs0 = pst.executeUpdate();
                                  if(rs0>0){
                                      //JOptionPane.showMessageDialog(register, "Data Saved Successfully go to back and login"); 
                                     Customer ln;
                                    ln = new Customer(uid);                             
                                    //setVisible(false);
                                    ln.setVisible(true);      
                                    jf.dispose();
                                    } 
                            }
                            
                        }
                        else{
                            JOptionPane.showMessageDialog(register, "Enter Correct Amount"); 
                        }
                        
                    }  
                    catch (Exception ex)   
                    {  
                        System.out.println(ex);  
                    }  
                }
             
               
             }
                if(e.getSource()==back)
                {
                    jf.dispose();
                     Customer ln;
                      ln = new Customer(uid);                             
                      //setVisible(false);
                      ln.setVisible(true);
                     
                }
              }
               
       
              public static boolean isamount(String s) 
            { 
                    String pattern = "^[0-9]{1,3}$";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
            }
               public static boolean isuname(String s) 
            { 
                      String pattern = "^([a-zA-Z]{2,}\\s[a-zA-z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
                   
            }
              
                public static boolean iscardno(String s) 
            { 
                      String pattern = "^(?:4[0-9]{12}(?:[0-9]{3})?)";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
                   
            }   
               
                 public static boolean iscvv(String s) 
            { 
                    String pattern = "[0-9]{3}";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
            }   
            public static boolean ismonth(String s) 
            { 
                //pattern1="((04)|(0[1-9]|1[012]))";
                 String pattern = "^((0[1-9])|(1[0-2]))$";
                
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
            }   
             public static boolean isyear(String s) 
            { 
                   
                  //pattern1="^-?0*(20[1-5][0-9]|205[0-5])$"
	          String pattern  = "^((2020)|20[2-4][0-9])$";	
                  
                    Pattern p=Pattern.compile(pattern);


                    Matcher mtch = p.matcher(s);
                    if(mtch.matches()){
                        return true;
                    }
                    return false;
            }   
             
            
             
             public boolean reg(){
            
            String amount =textfield1.getText();
            String uname=textfield2.getText();
            String cardno=textfield3.getText();
             String cvv=textfield4.getText();
             String month=textfield4a.getText();
             String year=textfield4b.getText();
             Date s=date.getDate();
            
                 
             
            if(isamount(amount))
            {
               at.setText("");
            }
            else{
               at.setText("Enter Your paper month cost");
            textfield1.requestFocusInWindow();
            return false;
            }
            
            if(isuname(uname))
            {
                an.setText("");
            }
            else
            {
               an.setText("Enter Correct Account Holder Name");
            textfield2.requestFocusInWindow();
            return false;
                
            }
            
            if(iscardno(cardno))
            {
                cn.setText("");
            }
            else
            {
             cn.setText("Card Number must be 16 digits and number should start with 4");
            textfield3.requestFocusInWindow();
            return false;
           
            }
            
            if(iscvv(cvv))
            {
                cv.setText("");
            }
            else{
              cv.setText("Enter Three digits of CVV number");
            textfield4.requestFocusInWindow();
            return false;
            }
             if(ismonth(month))
            {
                edate.setText("");
            }
            else{
              edate.setText("Enter Correct month");
            textfield4a.requestFocusInWindow();
            return false;
            }
            if(isyear(year))
            {
                edate.setText("");
            }
            else{
             edate.setText("Enter Correct Year");
            textfield4b.requestFocusInWindow();
            return false;
            }
            
            if(s==null)
            {
                dt.setText("choose Date");
                return false;
            }
            else
            {
                dt.setText("");
            }
                    
            return true;
         }  
       
       
        }
        

