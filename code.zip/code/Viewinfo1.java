/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Viewinfo1 extends JFrame implements ActionListener{

    JButton b2;
    JFrame frame1;
    Connection con;
    ResultSet rs, rs1;
    Statement st, st1;
    PreparedStatement pst;
    String ids;
    static JTable table;
    String[] columnNames = {"User name", "Email", "Password", "address","state","phone_no","Newspaper Name","Status"};
    Viewinfo1() throws Exception{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/npaas", "root", "");
            showTableData();
       }
    
    public void showTableData() {
//TableModel tm = new TableModel();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
//DefaultTableModel model = new DefaultTableModel(tm.getData1(), tm.getColumnNames());
//table = new JTable(model);
            frame1 = new JFrame("Database Search Result");
        
        //frame1.setLayout(new BorderLayout());
        frame1.setLayout(null);
        table = new JTable();
        table.setModel(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setFillsViewportHeight(true);
        table.setEnabled(false);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
    
       
      
         
        
        
//String textvalue = textbox.getText();
        String uname = "";
        String email = "";
        String pass = "";
        String cou = "";
        String address = "";
        String phoneno = "";
         String newspaper = "";
         String status="";
        try {
            pst = con.prepareStatement("select * from reg");
            ResultSet rs = pst.executeQuery();
            int i = 0;
            while (rs.next()) {
                uname = rs.getString("name");
                email = rs.getString("emailid");
                pass = rs.getString("pwd");
                cou = rs.getString("address");
                address = rs.getString("address");
                phoneno = rs.getString("phoneno");
                newspaper = rs.getString("newspaper");
                status=rs.getString("Status");
                model.addRow(new Object[]{uname, email, pass, cou,address,phoneno,newspaper,status});
                
                
               
                i++;
            }
            if (i < 1) {
                JOptionPane.showMessageDialog(null, "No Record Found", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if (i == 1) {
                System.out.println(i + " Record Found");
            } else {
                System.out.println(i + " Records Found");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        scroll.setBounds(5,40,1300,600);
        b2 = new JButton("Back");
        b2.setBounds(5, 0, 100, 37);
        frame1.add(scroll);        
        frame1.setSize(1500, 700);
        frame1.setVisible(true);
        frame1.add(b2);
        b2.addActionListener(this);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE );
        
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b2)
        { 
            	              //  JTable.close();
                                frame1.dispose();
				NewsAgent ln;
                                ln = new NewsAgent();
                                setVisible(false);
                                ln.setVisible(true);
                                dispose();
				
        }
    }
    
    
    public static void main(String args[]) throws Exception{
        new Viewinfo1();
    }

    


    
}